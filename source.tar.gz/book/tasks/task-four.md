## [T-#](id:section-num) Title Here

\![Awesome Placeholder Image](http://dummyimage.com/300/00/44.png&text=Awesome%20Placeholder "So awesome.")

### Summery
Words Here.


### Source
<script src=""></script>


### Results
    $ ./task-#.rb
    Results Here


### Details
Words Here.


### Extra Credit
1. Words Here.
2. Words Here.
3. Words Here.
