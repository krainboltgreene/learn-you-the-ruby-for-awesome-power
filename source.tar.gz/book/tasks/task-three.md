## [T-3](id:section-four) Nums, Interpolation, and Boolean
\![Awesome Placeholder Image](http://dummyimage.com/300/00/44.png&text=Awesome%20Placeholder "So awesome.")

### Summary
In this task we'll be learning about how Ruby handles numbers, math, and Boolean Operators. We'll also look into something called "Interpolation."

### Source
<script src="http://gist.github.com/654757.js?file=lyar3.rb"></script>
    

### Results
    $ ruby lyar3.rb
    > 

### Details
Like every good programming language Ruby understands basic Math easily. It knows that `2 + 2` is `4` and how PEMDAS works. Math is an important part of programming, but it's not required that you be a math genius. In fact most math programming you'll be doing will probably be the basic kind. With that said it's always good to know a few shortcuts! 

#### Extra Credit
1. 
2. 
3. 
