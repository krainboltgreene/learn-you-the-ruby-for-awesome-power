#!/usr/bin/env ruby
# encoding: utf-8
# author: "Kurtis Rainbolt-Greene"
# created: 2010.09.14-19:21:17

puts "A Boy And His Dog"
puts "================="
puts "It was a cold winter morning in the Forgotten Valley."
puts 'The boy looked to his dog and said, "Look there, Lucky!"'
puts '"The Temple of Golden Arches!" The dog glumly barked.'
puts "Venturing forth they climb down from the mountainside."
puts '"We are sure to find lost treasure!"'
puts 'The abandoned temple to the Golden Arches awaited.'


