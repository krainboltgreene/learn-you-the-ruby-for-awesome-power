#!/usr/bin/env ruby
# encoding: utf-8
# author: "Kurtis Rainbolt-Greene"
# created: 
