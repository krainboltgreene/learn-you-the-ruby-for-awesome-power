
Copyright
=========

[Learn You The Ruby For Awesome Power][0] by [Kurtis Rainbolt-Greene][1] is licensed under a [Creative Commons Attribution-ShareAlike 3.0 Unported License][2].

Based on a work at [learnyoutheruby.com][3].

[0]: http://learnyoutheruby.com
[1]: http://krainboltgreene.github.com/resume
[2]: http://creativecommons.org/licenses/by-sa/3.0/
[3]: http://learnyoutheruby.com/source.tar.gz
