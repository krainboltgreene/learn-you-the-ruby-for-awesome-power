Copyright
=========

[Learn You An Ruby For Awesome Power][0] by [Kurtis Rainbolt-Greene][1] is licensed under a [Creative Commons Attribution-ShareAlike 3.0 Unported License][2].

Based on a work at [learnyouanruby.info][3].

[0]: http://learnyouanruby.info
[1]: http://krainboltgreene.github.com/resume
[2]: http://creativecommons.org/licenses/by-sa/3.0/
[3]: http://learnyouanruby.info/source.tar.gz
